VEDA KOUSHIK PORTFOLIO - GITHUB PAGES

This package is structured for GitHub Pages.

IMPORTANT:
1. Extract this ZIP on your computer.
2. Open your GitHub repository.
3. Upload the CONTENTS of this folder (index.html, README.txt, and .nojekyll) to the repository root.
4. Commit the changes.
5. In GitHub, open Settings > Pages.
6. Under Build and deployment, choose Deploy from a branch, select your main branch and /(root), then Save.
7. Wait for the Pages deployment to finish. Open the published URL shown in Settings > Pages.

Do not upload the ZIP as the only file and expect GitHub Pages to publish it. GitHub Pages needs index.html extracted at the selected publishing root.

The resume page is embedded inside index.html. No separate resume.html is required.
